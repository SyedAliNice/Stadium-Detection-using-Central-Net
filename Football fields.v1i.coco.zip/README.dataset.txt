# Football fields > 2024-06-01 6:31pm
https://universe.roboflow.com/insekty/football-fields-ihnum

Provided by a Roboflow user
License: CC BY 4.0

